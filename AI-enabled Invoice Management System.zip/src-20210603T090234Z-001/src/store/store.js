import { createStore } from 'redux';
import reducer from './reducers/reducer.js'


export default store = createStore(reducer);
export default function search(value)
{
    return {
      type : "change",
      payload:  value
    };
}
import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import InputLabel from '@material-ui/core/InputLabel';
import TextField from '@material-ui/core/TextField';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';

import { Snackbar } from '@material-ui/core';


const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  paper: {
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.primary,
    
  },
  p:{
      color: 'grey',
  }
}));

export default function AddInvoiceForm() {
  const classes = useStyles();

  return (

 <div className={classes.root}>
     <div>
     <p>
     <font color='grey'>Subject:</font> Invoice Details - EnterAccountNameHere
     </p>
     </div>
     <div>
     <p>
     Dear Sir/Madam, Greetings! This is to remind you that there are one or more open invoices on your account. 
     Please provide at your earliest convenience an update on the payment details or clarify the reason for the delay.
     If you have any specific issue with the invoice(s), please let us know so that we can address it to the correct Department. 
     
     </p>
     </div>
     <div>
        <p>Please find the details of the invoices below:</p>
     </div>
     <div styles={{height: '20vh'}}> Make table here </div>

    <div>
        <p styles={{color: '#C0C6CA'}}>Total Amount to be Paid: $124.00K </p>
        <p> In case you have already made a payment for the above items, please send us the details to ensure the payment is posted. 
            Let us know if we can be of any further assistance. 
            Looking forward to hearing from you. 
            Kind Regards, [Sender’s First Name][Sender’s Last Name] Phone : [Sender’s contact number] Fax : [If any] Email : [Sender’s Email Address] Company Name[Sender’s Company Name]</p>
    </div>


  </div>
 
  );
}